dataE = 
    {
        "apiKey": "K-***",
        "apiSecret": "S-***"
    };

